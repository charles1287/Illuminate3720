﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class CropInteractionScript : MonoBehaviour
{

    float _currentValue;


    
}
