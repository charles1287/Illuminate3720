﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PodLinking : MonoBehaviour
{
    public GameObject AirPodPrefab;
    public GameObject WaterPodPrefab;
    public GameObject PowerPodPrefab;

	public int airPodPrefab = 0;
	public int waterPodPrefab = 0;
	public int powerPodPrefab = 0;

    public void MakeAirPod(GameObject selectMenu)
    {
        Instantiate(AirPodPrefab, transform, false);
        selectMenu.SetActive(false);

		airPodPrefab++;
    }

    public void MakePowerPod(GameObject selectMenu)
    {
        Instantiate(PowerPodPrefab, transform, false);
        selectMenu.SetActive(false);

		waterPodPrefab++;
    }

    public void MakeWaterPod(GameObject selectMenu)
    {
        Instantiate(WaterPodPrefab, transform, false);
        selectMenu.SetActive(false);

		powerPodPrefab++;
    }
}
