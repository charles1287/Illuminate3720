﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Resources : MonoBehaviour {

    //[HideInInspector]
    public float Water = 20f;
    //[HideInInspector]
    public float Ice = 20f;
    //[HideInInspector]
    public float Power = 20f;
    //[HideInInspector]
    public float Fuel = 20f;
    //[HideInInspector]
    public float Food = 20f;
}
